/**
 * 
 */
/**
 * 
 */
module CameraRental {
}