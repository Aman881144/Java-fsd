package filehandling;

import java.io.*;

public class FileHandling {

public static void main(String[] args) {
String filePath = "example.txt";
writeToFile(filePath, "Hello, My name is Aman.");
String content = readFromFile(filePath);
System.out.println("Content read from the file: " + content);
appendToFile(filePath, "\nThis text is appended.");
content = readFromFile(filePath);
System.out.println("Updated content read from the file: " + content);
}

private static void writeToFile(String filePath, String content) {
try (PrintWriter writer = new PrintWriter(filePath)) {
writer.println(content);
} catch (FileNotFoundException e) {
e.printStackTrace();
}
}

private static String readFromFile(String filePath) {
StringBuilder content = new StringBuilder();
try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
String line;
while ((line = reader.readLine()) != null) {
content.append(line).append("\n");
}
} catch (IOException e) {
e.printStackTrace();
}
return content.toString();
}

private static void appendToFile(String filePath, String content) {
try (FileWriter writer = new FileWriter(filePath, true)) {
writer.write(content);
} catch (IOException e) {
e.printStackTrace();
}
}
}

