package project4;

public class Constructor {

	public static void main(String[] args) {
		// Using the default constructor
        Person person1 = new Person();
        System.out.println("Using Default Constructor:");
        person1.displayInfo();
        System.out.println();

        // Using the parameterized constructor
        Person person2 = new Person("Saurabh", 24);
        System.out.println("Using Parameterized Constructor:");
        person2.displayInfo();
        System.out.println();

        // Using constructor overloading
        Person person3 = new Person("Ajay");
        System.out.println("Using Constructor Overloading:");
        person3.displayInfo();

	}

}
