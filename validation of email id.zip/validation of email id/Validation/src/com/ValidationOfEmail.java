package com;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationOfEmail {
	 private static final String EMAIL_REGEX =
	            "^[a-zA-Z0-9_+&-]+(?:\\.[a-zA-Z0-9_+&-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

	    private static final Pattern pattern = Pattern.compile(EMAIL_REGEX);

	    public static boolean isValidEmail(String email) {
	        Matcher matcher = pattern.matcher(email);
	        return matcher.matches();
	    }

	public static void main(String[] args) {
		 String email1 = "user@example.com";
	        String email2 = "invalid-email";

	        System.out.println(email1 + " is valid: " + isValidEmail(email1));
	        System.out.println(email2 + " is valid: " + isValidEmail(email2));

	}

}
