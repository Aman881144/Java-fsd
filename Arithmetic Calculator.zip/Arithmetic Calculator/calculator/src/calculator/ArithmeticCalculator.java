package calculator;
import java.util.Scanner;
public class ArithmeticCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  int a,b,m;
				Scanner sc = new Scanner(System.in);
				System.out.println("enter a number");
				a=sc.nextInt();
				System.out.println("enter another number");
				b=sc.nextInt()	;
				System.out.println("1. add");
				System.out.println("2. sub");
				System.out.println("3. mul");
				System.out.println("4. div");
				
				m=sc.nextInt();
				
				if(m == 1)
				{
					System.out.println("answer is :"+ (a+b) );
				}
				else if(m == 2)
				{
					System.out.println("answer is :"+ (a-b) );
				}
				else if(m == 3)
				{
					System.out.println("answer is :"+ (a*b) );
				}
				else if(m == 4 && b!=0)
				{
				 
					System.out.println("answer is :"+ (a/b) );
				}
				else 
				{
					System.out.println(" for div the second number can not be zero");
				}
				
				

	}

}
